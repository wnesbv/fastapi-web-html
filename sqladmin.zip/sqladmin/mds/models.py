
from fastapi import Depends, Request

from sqladmin import ModelAdmin

from models.mls.user import User


class AuthModelAdmin(ModelAdmin):
    def is_accessible(
        self,
        request: Request,
    ) -> bool:

        return True


    def is_visible(self, request: Request) -> bool:
        return True


class UserAdmin(AuthModelAdmin, model=User):
    column_list = [User.id, User.name]
