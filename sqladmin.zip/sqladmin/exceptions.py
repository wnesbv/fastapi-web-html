class InvalidModelError(Exception):
    pass


class InvalidColumnError(Exception):
    pass
